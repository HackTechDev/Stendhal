/**
 * a text client, mostly for support stuff.<!--sic--> Please be responsible with bots.
 */
package games.stendhal.bot.textclient;



/* $Id: package-info.java,v 1.1 2010/11/29 21:39:06 nhnb Exp $ */
/***************************************************************************
 *                   (C) Copyright 2003-2010 - Stendhal                    *
 ***************************************************************************
 ***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/
