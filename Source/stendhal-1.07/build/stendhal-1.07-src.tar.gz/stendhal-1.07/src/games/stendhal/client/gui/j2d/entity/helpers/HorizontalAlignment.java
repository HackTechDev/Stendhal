package games.stendhal.client.gui.j2d.entity.helpers;
/**
 * Representation for horizontal alignment
 * 
 * @author madmetzger
 */
public enum HorizontalAlignment {
	
	LEFT,
	RIGHT,
	CENTER;

}
