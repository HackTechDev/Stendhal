package games.stendhal.client.gui.j2d.entity.helpers;
/**
 * Representation for vertical alignment
 * 
 * @author madmetzger
 */
public enum VerticalAlignment {
	
	TOP,
	MIDDLE,
	BOTTOM;

}
