If you add text to an image which is likly to get outdated,
please save the complete file in a layered format like Gimp's
.xcf, too. Only the .png file will be included in the client
distribution so the download size will not be increased by this.